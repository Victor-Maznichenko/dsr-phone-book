import { createBrowserRouter, RouterProvider } from 'react-router';
import { AppShell } from '@mantine/core';
import { HomePage, LoginPage, NotFoundPage, RegisterPage, UserPage } from '@/pages';
import { ProtectedRoute } from './protected-route';
import { Footer, Header } from '@/shared/ui';
import { useAuth } from '@/shared/lib/hooks';

// TODO
// Тут был пройобан Layout
// Тут надо вынести роуты
const router = createBrowserRouter([
  {
    path: '/',
    errorElement: <NotFoundPage />,
    children: [
      {
        element: <ProtectedRoute />,
        children: [
          { index: true, element: <HomePage /> },
          { path: 'users/:id', element: <UserPage /> },
        ],
      },
      { path: 'login', element: <LoginPage /> },
      { path: 'register', element: <RegisterPage /> },
      { path: 'admin/login', element: <LoginPage isAdmin /> },
    ],
  },
]);

export const App = () => {
  useAuth();

  return (
    <AppShell>
      <Header />
      <RouterProvider router={router} />
      <Footer />
    </AppShell>
  );
};
