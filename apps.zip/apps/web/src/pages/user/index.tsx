import { useEffect } from 'react';
import { useParams } from 'react-router';
import { Group, Avatar, Text, AppShell, Container, Paper, SimpleGrid, Button } from '@mantine/core';
import { useForm } from '@mantine/form';
import { zod4Resolver } from 'mantine-form-zod-resolver';
import { useUserStore } from '@/shared/store';
import { credentialsFormSchema, personalFormSchema } from '@/shared/lib';
import styles from './styles.module.css';
import { TextInput, Textarea } from '@/shared/ui';

/* 
Надо сделать форму в которой я смогу поменять поля какие-то
Для консистентности неизменяемые поля будут input disabled
Все это будет одной единой формой

Изменяемые поля:
- email
- firstName 
- lastName
- officePhone
- department
- position
- officeAddress
- about
- avatar
*/

/* 
Надо добавить методы изменения user в store
После чего взять из login форму

Должно быть отдельными формами или нет?
Нужно посмотреть пример на каком-то сайте: хабр, 
*/
export const UserPage = () => {
  const { id } = useParams();
  const { user, isLoading, getUserById } = useUserStore();
  const form = useForm({
    mode: 'controlled',
    initialValues: user as unknown as Record<string, unknown>,
    validate: zod4Resolver(personalFormSchema.extend(credentialsFormSchema.shape)),
  });

  useEffect(() => {
    if (!isLoading) {
      form.setValues(user as unknown as Record<string, unknown>);
    }
  }, [isLoading]);

  useEffect(() => {
    getUserById(id ?? '');
  }, []);

  if (isLoading) {
    return 'Loading...';
  }

  return (
    <AppShell.Main py={100}>
      <Container size="lg">
        <Group align="flex-start" wrap="nowrap">
          <Paper
            maw="calc(18.75rem * var(--mantine-scale) + var(--mantine-spacing-md) * 2)"
            radius="md"
            ta="center"
            withBorder
            p="md"
          >
            <Text fz="h2" fw={500} className={styles.name}>
              {user?.firstName} {user?.lastName}
            </Text>
            <Avatar src={user?.avatar} size={300} radius="md" />
          </Paper>

          <Paper flex="1 0 auto" radius="md" withBorder p="md">
            <Text mb="xl" fz="h2" fw={500} className={styles.name}>
              Bio & other details
            </Text>

            <SimpleGrid cols={2} component="form">
              <TextInput
                label="First Name"
                key={form.key('firstName')}
                {...form.getInputProps('firstName')}
                error={form.errors.firstName}
              />

              <TextInput
                label="Last Name"
                key={form.key('lastName')}
                {...form.getInputProps('lastName')}
                error={form.errors.lastName}
              />

              <TextInput
                label="Email"
                key={form.key('email')}
                {...form.getInputProps('email')}
                error={form.errors.email}
              />

              <TextInput
                label="Department"
                key={form.key('department')}
                {...form.getInputProps('department')}
                error={form.errors.department}
              />

              <TextInput
                label="Position"
                key={form.key('position')}
                {...form.getInputProps('position')}
                error={form.errors.position}
              />

              <TextInput
                label="Office Address"
                key={form.key('officeAddress')}
                {...form.getInputProps('officeAddress')}
                error={form.errors.officeAddress}
              />

              <Textarea
                label="About"
                key={form.key('about')}
                {...form.getInputProps('about')}
                style={{ gridColumn: 'span 2' }}
                error={form.errors.about}
              />

              <Button
                style={{ gridColumn: 'span 2' }}
                type="submit"
                variant="filled"
                fullWidth
                color="indigo"
                size="xl"
                radius="lg"
              >
                Save
              </Button>
            </SimpleGrid>
          </Paper>
        </Group>
      </Container>
    </AppShell.Main>
  );
};
