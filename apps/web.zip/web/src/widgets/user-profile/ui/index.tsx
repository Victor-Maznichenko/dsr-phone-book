import { FC, PropsWithChildren } from "react";
import { UserProfileContext, UserProfileContextType, useUserProfile } from "../lib";
import { Button, Flex, Group, Paper, Select, SimpleGrid, Textarea, TextInput, Text } from "@mantine/core";
import { zod4Resolver } from 'mantine-form-zod-resolver';
import { pick } from "es-toolkit/compat";
import { credentialsFormSchema, DEPARTMENTS, personalFormSchema, POSITIONS } from "@/shared/lib";
import { AvatarUploader, InputPhone, LabelValue } from "@/shared/ui";
import { useForm } from "@mantine/form";

interface UserProfileProps extends UserProfileContextType, PropsWithChildren { }

interface UserProfileCompound {
  Preview: React.FC;
  EditableInfo: React.FC;
  Info: React.FC;
}

export const UserProfile: FC<UserProfileProps> & UserProfileCompound = ({ state, actions, children }) => (
  <UserProfileContext.Provider value={{ state, actions }}>
    <Group align="flex-start" wrap="nowrap">{children}</Group>
  </UserProfileContext.Provider>
);

UserProfile.EditableInfo = () => {
  const { state } = useUserProfile();

  return (
    <Paper flex="1 0 auto" radius="md" withBorder p="md">
      <Flex mb="xl" align="center" justify="space-between">
        <Text fz="h2" fw={500}>
          Bio & other details
        </Text>
      </Flex>

      <SimpleGrid cols={2} component="form">
        <LabelValue
          label="First Name"
          value={state?.firstName}
        />
        <LabelValue
          label="Last Name"
          value={state?.lastName}
        />
        <LabelValue
          label="Email"
          value={state?.email}
        />
        <LabelValue
          label="Office Address"
          value={state?.officeAddress}
        />
        <LabelValue
          label="Department"
          value={state?.department}
        />
        <LabelValue
          label="Position"
          value={state?.position}
        />
        <LabelValue
          label="Office phone"
          value={state?.officePhone}
        />
        <LabelValue
          label="About"
          value={state?.about}
        />
      </SimpleGrid>
    </Paper>
  )
};

UserProfile.Preview = () => {
  const { state } = useUserProfile();
  
  return (
    <Paper
      maw="calc(18.75rem * var(--mantine-scale) + var(--mantine-spacing-md) * 2)"
      radius="md"
      ta="center"
      withBorder
      p="md"
    >
      <Text fz="h2" fw={500}>
        {state?.firstName} {state?.lastName}
      </Text>

      <AvatarUploader src={state?.avatar} />
    </Paper>
  )
};

UserProfile.Info = () => {
  const { state } = useUserProfile();
  const personalFormValues = pick(state, [
    'email',
    'firstName',
    'lastName',
    'officePhone',
    'department',
    'position',
    'officeAddress',
    'about',
  ]);

  const form = useForm({
    mode: 'controlled',
    initialValues: personalFormValues,
    validate: zod4Resolver(personalFormSchema.extend(credentialsFormSchema.shape)),
  });

  return (
    <Paper flex="1 0 auto" radius="md" withBorder p="md">
      <Flex mb="xl" align="center" justify="space-between">
        <Text fz="h2" fw={500}>
          Bio & other details
        </Text>
      </Flex>

      <SimpleGrid cols={2} component="form">
        <TextInput
          disabled
          label="First Name"
          key={form.key('firstName')}
          {...form.getInputProps('firstName')}
          error={form.errors.firstName}
        />

        <TextInput
          disabled
          label="Last Name"
          key={form.key('lastName')}
          {...form.getInputProps('lastName')}
          error={form.errors.lastName}
        />

        <TextInput
          disabled
          label="Email"
          key={form.key('email')}
          {...form.getInputProps('email')}
          error={form.errors.email}
        />

        <TextInput
          disabled
          label="Office Address"
          key={form.key('officeAddress')}
          {...form.getInputProps('officeAddress')}
          error={form.errors.officeAddress}
        />

        <Select
          disabled
          label="Department"
          data={Object.values(DEPARTMENTS)}
          key={form.key('department')}
          error={form.errors.department}
          {...form.getInputProps('department')}
          styles={{ options: { textTransform: 'uppercase' }, input: { textTransform: 'uppercase' } }}
        />

        <Select
          disabled
          label="Position"
          data={Object.values(POSITIONS)}
          key={form.key('position')}
          error={form.errors.position}
          {...form.getInputProps('position')}
          styles={{ options: { textTransform: 'uppercase' }, input: { textTransform: 'uppercase' } }}
        />

        <InputPhone
          disabled
          label="Office phone"
          key={form.key('officePhone')}
          {...form.getInputProps('officePhone')}
          error={form.errors.officePhone}
        />

        <Textarea
          disabled
          label="About"
          key={form.key('about')}
          {...form.getInputProps('about')}
          style={{ gridColumn: 'span 2' }}
          error={form.errors.about}
        />

        <Button
          disabled
          style={{ gridColumn: 'span 2' }}
          type="submit"
          variant="filled"
          fullWidth
          color="indigo"
          size="xl"
          radius="lg"
        >
          Save
        </Button>
      </SimpleGrid>
    </Paper>
  )
}
