import { createContext, useContext } from "react";

type UserProfileState = Pick<UserResponse, 
'email' |
'firstName' |
'lastName' |
'officePhone' |
'department' |
'position' |
'officeAddress' |
'about' |
'avatar'
>;

interface UserProfileActions { 
    delete?: () => void; 
    updateInfo?: (info: any) => void; 
    updateAvatar?: (avatar: string) => void 
};

export type UserProfileContextType = {
    state: UserProfileState;
    actions: UserProfileActions;
};

export const UserProfileContext = createContext<Nullable<UserProfileContextType>>(null);

export const useUserProfile = () => {
    const context = useContext(UserProfileContext);
    if (!context) throw new Error('');
    return context;
};

