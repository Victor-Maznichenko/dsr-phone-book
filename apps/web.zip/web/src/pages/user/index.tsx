import { useEffect, useMemo, useState } from 'react';
import { pick } from 'es-toolkit/compat';
import { useParams } from 'react-router';
import { Group, Text, AppShell, Container, Paper, SimpleGrid, Button, Flex } from '@mantine/core';
import { useForm } from '@mantine/form';
import { zod4Resolver } from 'mantine-form-zod-resolver';
import { AvatarUploader } from '@/shared/ui/avatar-uploader';
import { useProfileStore, useUserStore } from '@/shared/store';
import { credentialsFormSchema, DEPARTMENTS, personalFormSchema, POSITIONS } from '@/shared/lib';
import styles from './styles.module.css';
import { InputPhone, Select, TextInput, Textarea } from '@/shared/ui';

/* 
Надо сделать форму в которой я смогу поменять поля какие-то
Для консистентности неизменяемые поля будут input disabled
Все это будет одной единой формой

Изменяемые поля:
- email
- firstName 
- lastName
- officePhone
- department
- position
- officeAddress
- about
- avatar
*/

/* 
Надо добавить методы изменения user в store
После чего взять из login форму

Должно быть отдельными формами или нет?
Нужно посмотреть пример на каком-то сайте: хабр, 
*/

export const UserPage = () => {
  const { id } = useParams();
  const [isDisabled, setDisabled] = useState(true);
  const { user, isLoading, getUserById } = useUserStore();
  const { isAdmin } = useProfileStore();
  const personalFormValues = useMemo(
    () =>
      pick(user, [
        'email',
        'firstName',
        'lastName',
        'officePhone',
        'department',
        'position',
        'officeAddress',
        'about',
        'avatar',
      ]),
    [user],
  );

  const form = useForm({
    mode: 'controlled',
    initialValues: personalFormValues,
    validate: zod4Resolver(personalFormSchema.extend(credentialsFormSchema.shape)),
  });

  useEffect(() => {
    if (!isLoading) {
      form.setValues(personalFormValues);
    }
  }, [isLoading]);

  useEffect(() => {
    getUserById(id ?? '');
  }, []);

  if (isLoading) {
    return 'Loading...';
  }

  return (
    <AppShell.Main py={100}>
      <Container size="lg">
        <Group align="flex-start" wrap="nowrap">
          <Paper
            maw="calc(18.75rem * var(--mantine-scale) + var(--mantine-spacing-md) * 2)"
            radius="md"
            ta="center"
            withBorder
            p="md"
          >
            <Text fz="h2" fw={500} className={styles.name}>
              {user?.firstName} {user?.lastName}
            </Text>

            <AvatarUploader src={user?.avatar} />
          </Paper>

          <Paper flex="1 0 auto" radius="md" withBorder p="md">
            <Flex mb="xl" align="center" justify="space-between">
              <Text fz="h2" fw={500} className={styles.name}>
                Bio & other details
              </Text>
              {isAdmin && (
                <Button onClick={() => setDisabled((prev) => !prev)}>{isDisabled ? 'Edit' : 'Cancel'}</Button>
              )}
            </Flex>

            <SimpleGrid cols={2} component="form">
              <TextInput
                disabled={isDisabled}
                label="First Name"
                key={form.key('firstName')}
                {...form.getInputProps('firstName')}
                error={form.errors.firstName}
              />

              <TextInput
                disabled={isDisabled}
                label="Last Name"
                key={form.key('lastName')}
                {...form.getInputProps('lastName')}
                error={form.errors.lastName}
              />

              <TextInput
                disabled={isDisabled}
                label="Email"
                key={form.key('email')}
                {...form.getInputProps('email')}
                error={form.errors.email}
              />

              <TextInput
                disabled={isDisabled}
                label="Office Address"
                key={form.key('officeAddress')}
                {...form.getInputProps('officeAddress')}
                error={form.errors.officeAddress}
              />

              <Select
                disabled={isDisabled}
                label="Department"
                data={Object.values(DEPARTMENTS)}
                key={form.key('department')}
                error={form.errors.department}
                {...form.getInputProps('department')}
                styles={{ options: { textTransform: 'uppercase' }, input: { textTransform: 'uppercase' } }}
              />

              <Select
                disabled={isDisabled}
                label="Position"
                data={Object.values(POSITIONS)}
                key={form.key('position')}
                error={form.errors.position}
                {...form.getInputProps('position')}
                styles={{ options: { textTransform: 'uppercase' }, input: { textTransform: 'uppercase' } }}
              />

              <InputPhone
                disabled={isDisabled}
                label="Office phone"
                key={form.key('officePhone')}
                {...form.getInputProps('officePhone')}
                error={form.errors.officePhone}
              />

              <Textarea
                disabled={isDisabled}
                label="About"
                key={form.key('about')}
                {...form.getInputProps('about')}
                style={{ gridColumn: 'span 2' }}
                error={form.errors.about}
              />

              <Button
                disabled={isDisabled || true}
                style={{ gridColumn: 'span 2' }}
                type="submit"
                variant="filled"
                fullWidth
                color="indigo"
                size="xl"
                radius="lg"
              >
                Save
              </Button>
            </SimpleGrid>
          </Paper>
        </Group>
      </Container>
    </AppShell.Main>
  );
};
