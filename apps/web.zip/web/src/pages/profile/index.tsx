
export const Profile = () => (
    <AppShell.Main py={100} ta="center">
    <Container size="lg">
      <Title mb="xl">Profile:</Title>
      
    </Container>
  </AppShell.Main>
  )
