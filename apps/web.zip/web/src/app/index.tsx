import { createBrowserRouter, Outlet, RouterProvider } from 'react-router';
import { AppShell } from '@mantine/core';
import { HomePage, LoginPage, NotFoundPage, RegisterPage, UserPage } from '@/pages';
import { ProtectedRoute } from './protected-route';
import { Footer, Header } from '@/shared/ui';
import { useAuth, ROUTES } from '@/shared/lib';

const Layout = () => (
  <AppShell>
    <Header />
    <Outlet />
    <Footer />
  </AppShell>
);

const router = createBrowserRouter([
  {
    path: ROUTES.ROOT,
    element: <Layout />,
    errorElement: <NotFoundPage />,
    children: [
      {
        element: <ProtectedRoute />,
        children: [
          { index: true, element: <HomePage /> },
          { path: ROUTES.USER, element: <UserPage /> },
        ],
      },
      { path: ROUTES.LOGIN, element: <LoginPage /> },
      { path: ROUTES.REGISTER, element: <RegisterPage /> },
      { path: ROUTES.ADMIN_LOGIN, element: <LoginPage isAdmin /> },
    ],
  },
]);

export const App = () => {
  useAuth();

  return <RouterProvider router={router} />;
};
